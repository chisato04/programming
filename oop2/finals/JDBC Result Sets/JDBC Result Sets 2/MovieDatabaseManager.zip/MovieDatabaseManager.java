
import java.sql.*;
import java.util.ArrayList;
import java.util.List;

class Movie {
    private int id;
    private String title;
    private String director;
    private float rating;

    public Movie(int id, String title, String director, float rating) {
        this.id = id;
        this.title = title;
        this.director = director;
        this.rating = rating;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public String getDirector() {
        return director;
    }

    public void setDirector(String director) {
        this.director = director;
    }

    public float getRating() {
        return rating;
    }

    public void setRating(float rating) {
        this.rating = rating;
    }

    @Override
    public String toString() {
        return "Movie ID: " + id +
                "\nTitle: " + title +
                "\nDirector: " + director +
                "\nRating: " + String.format("%.1f", rating);
    }
}

public class MovieDatabaseManager {
    private String databaseUrl;
    private String username;
    private String password;

    public MovieDatabaseManager(String databaseUrl, String username, String password) {
        this.databaseUrl = databaseUrl;
        this.username = username;
        this.password = password;
    }

    public Connection getDatabaseConnection() throws SQLException {
        return DriverManager.getConnection(databaseUrl, username, password);
    }

    public boolean registerMovie(String title, String director, float rating) {
        try (Connection connection = getDatabaseConnection();
                PreparedStatement preparedStatement = connection.prepareStatement(
                        "INSERT INTO movie (title, director, rating) VALUES (?, ?, ?)")) {
            preparedStatement.setString(1, title);
            preparedStatement.setString(2, director);
            preparedStatement.setFloat(3, rating);

            int rowsAffected = preparedStatement.executeUpdate();
            return rowsAffected > 0;
        } catch (SQLException e) {
            e.printStackTrace();
            return false;
        }
    }

    public Movie retrieveMovie(int id) {
        try (Connection connection = getDatabaseConnection();
                PreparedStatement preparedStatement = connection.prepareStatement("SELECT * FROM movie WHERE id = ?")) {
            preparedStatement.setInt(1, id);
            ResultSet resultSet = preparedStatement.executeQuery();

            if (resultSet.next()) {
                String title = resultSet.getString("title");
                String director = resultSet.getString("director");
                float rating = resultSet.getFloat("rating");

                return new Movie(id, title, director, rating);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return null;
    }

    public List<Movie> retrieveMovies() {
        List<Movie> movies = new ArrayList<>();
        try (Connection connection = getDatabaseConnection();
                Statement statement = connection.createStatement();
                ResultSet resultSet = statement.executeQuery("SELECT * FROM movie")) {

            while (resultSet.next()) {
                int id = resultSet.getInt("id");
                String title = resultSet.getString("title");
                String director = resultSet.getString("director");
                float rating = resultSet.getFloat("rating");

                movies.add(new Movie(id, title, director, rating));
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return movies;
    }

    public static void main(String[] args) {
        String databaseUrl = "jdbc:mysql://localhost:3306/mydatabase";
        String username = "username";
        String password = "password";

        MovieDatabaseManager manager = new MovieDatabaseManager(databaseUrl, username, password);

        boolean exit = false;
        while (!exit) {
            System.out.println("Choose what to do:");
            System.out.println("1. Register Movie");
            System.out.println("2. Retrieve Movie");
            System.out.println("3. List All Movies");
            System.out.println("0. Exit");
            System.out.print("Choice: ");

            int choice = 1;

            switch (choice) {
                case 1:
                    System.out.println("Enter Movie Details");
                    String movieTitle = "CodeChum the Movie";
                    String movieDirector = "John Doe";
                    float movieRating = 5.0f;

                    System.out.println("Title: " + movieTitle);
                    System.out.println("Director: " + movieDirector);
                    System.out.println("Rating: " + movieRating);
                    System.out.print("Proceed to save? (Y/n) ");

                    String input = "Y";

                    if (input.equalsIgnoreCase("Y")) {
                        boolean saved = manager.registerMovie(movieTitle, movieDirector, movieRating);
                        if (saved) {
                            System.out.println("Successfully saved!");
                        } else {
                            System.out.println("Failed to save!");
                        }
                    } else {
                        System.out.println("Operation canceled by user.");
                    }
                    break;
                case 2:
                    System.out.print("Enter Movie ID: ");
                    int movieId = 1;

                    Movie movie = manager.retrieveMovie(movieId);
                    if (movie != null) {
                        System.out.println("Retrieve movie? (Y/n): ");
                        String confirmInput = "Y";
                        if (confirmInput.equalsIgnoreCase("Y")) {
                            System.out.println("Movie Details:");
                            System.out.println(movie);
                        }
                    } else {
                        System.out.println("Movie not found!");
                    }
                    break;
                case 3:
                    List<Movie> allMovies = manager.retrieveMovies();
                    System.out.println("All Movies:");
                    for (Movie m : allMovies) {
                        System.out.println(m);
                    }
                    break;
                case 0:
                    exit = true;
                    System.out.println("Exiting...");
                    break;
                default:
                    System.out.println("Invalid choice! Please try again.");
            }
        }
    }
}
